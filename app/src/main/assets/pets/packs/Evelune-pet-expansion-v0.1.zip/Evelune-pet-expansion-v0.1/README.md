# Evelune Pet Expansion v0.1

Production-style asset pack for the 10 newly generated pets.

Each pet contains:
- 8 transparent PNG sprite/state frames
- 1 GIF state preview
- manifest.json
- README.md

This pack is intended to sit alongside the existing puppy and kitten asset pack.
