# Hedgehog

Rarity: Uncommon

Base hatch chance: 10.0%

Contains 8 transparent PNG frames plus a GIF preview.
