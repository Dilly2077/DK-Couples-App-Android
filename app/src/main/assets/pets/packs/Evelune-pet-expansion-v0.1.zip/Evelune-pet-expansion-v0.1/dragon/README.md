# Dragon

Rarity: Mythic

Base hatch chance: 1.0%

Contains 8 transparent PNG frames plus a GIF preview.
