# Axolotl

Rarity: Rare

Base hatch chance: 5.0%

Contains 8 transparent PNG frames plus a GIF preview.
