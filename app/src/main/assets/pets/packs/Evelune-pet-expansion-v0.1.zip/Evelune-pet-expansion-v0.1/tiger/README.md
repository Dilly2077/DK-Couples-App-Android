# Tiger

Rarity: Legendary

Base hatch chance: 4.0%

Contains 8 transparent PNG frames plus a GIF preview.
