# Bunny

Rarity: Common

Base hatch chance: 12.5%

Contains 8 transparent PNG frames plus a GIF preview.
