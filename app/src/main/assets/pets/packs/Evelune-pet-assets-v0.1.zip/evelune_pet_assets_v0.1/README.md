# Evelune Pet Assets v0.1

This pack converts the generated pet art into a cleaner production-style folder structure.

## What is included
- Individual PNG character assets for Mocha and Lumi.
- Individual PNG egg hatching stages.
- Individual PNG prop and thought-bubble assets.
- Four environment backgrounds: room, kitchen, bathroom, and garden.
- Preview GIFs for simple animation checks.
- `manifest.json` and `animation_presets.json` for integration guidance.

## Intended environment usage
- `room_playroom.png`: default indoor home scene.
- `kitchen_feeding_room.png`: feeding / water interactions.
- `bathroom_cleaning_room.png`: cleaning / bath interactions.
- `garden_outdoor_room.png`: outdoor play / exploration.

## Important note
These assets are organised locally now, but they have not yet been committed into the GitHub repo in this environment.
